from modeller import *    # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

log.verbose()  #request verbose output
env = environ()  #create a new MODELLER environment to build this model
env.io.atom_files_directory = ['.'] #directories of input atom files

a = automodel(env,
              alnfile  = 'bak_T1006.pir',      # alignment filename
              knowns = ( 'meta_center2.pdb1',  'meta_hs2.pdb1',  'meta_novel5.pdb1',  'meta_star3.pdb1',  'meta_hs1.pdb1',  'meta_star2.pdb1',  'meta_hs3.pdb1',  'meta_ss6.pdb1',  'meta_hh6.pdb1',  'meta_ff7.pdb1',  'meta_hhsuite1.pdb1',  'meta_novel1.pdb1',  'meta_star0.pdb1',  'meta_hh4.pdb1',  'meta_center0.pdb1',  'meta_rapt4.pdb1',  'meta_msaprobs2.pdb1',  'meta_novel3.pdb1',  'meta_rapt3.pdb1',  'meta_multicom9.pdb1'), # codes of the templates
              sequence = 'T1006')   # code of the target
a.starting_model= 1             # index of the first model
a.ending_model  = 8    # index of the last model

a.make()
