from modeller import *    # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

log.verbose()  #request verbose output
env = environ()  #create a new MODELLER environment to build this model
env.io.atom_files_directory = ['.'] #directories of input atom files

a = automodel(env,
              alnfile  = 'bak_T0971.pir',      # alignment filename
              knowns = ( 'meta_ss3.pdb1',  'meta_hmmer1.pdb1',  'meta_hg3.pdb1',  'meta_novel2.pdb1',  'meta_hs1.pdb1',  'meta_ss2.pdb1',  'meta_novel1.pdb1',  'meta_hg1.pdb1',  'meta_ap1.pdb1',  'meta_rapt1.pdb1',  'meta_com1.pdb1',  'meta_blits1.pdb1',  'meta_hp1.pdb1',  'meta_sam1.pdb1',  'meta_center0.pdb1',  'meta_jackhmmer3.pdb1',  'meta_jackhmmer2.pdb1',  'meta_star0.pdb1',  'meta_msaprobs0.pdb1',  'meta_hh1.pdb1'), # codes of the templates
              sequence = 'T0971')   # code of the target
a.starting_model= 1             # index of the first model
a.ending_model  = 8    # index of the last model

a.make()
