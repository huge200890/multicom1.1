from modeller import *    # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

log.verbose()  #request verbose output
env = environ()  #create a new MODELLER environment to build this model
env.io.atom_files_directory = ['.'] #directories of input atom files

a = automodel(env,
              alnfile  = 'bak_T1008.pir',      # alignment filename
              knowns = ( 'meta_hhsuite4.pdb1',  'meta_blits6.pdb1',  'meta_hhsuite1.pdb1',  'meta_blits4.pdb1',  'meta_ap4.pdb1',  'meta_hhsuite5.pdb1',  'meta_hhsuite6.pdb1',  'meta_hhsuite10.pdb1',  'meta_hhsuite9.pdb1',  'meta_blits8.pdb1',  'meta_ap2.pdb1',  'meta_blits2.pdb1',  'meta_hhsuite7.pdb1',  'meta_hhsuite3.pdb1'), # codes of the templates
              sequence = 'T1008')   # code of the target
a.starting_model= 1             # index of the first model
a.ending_model  = 8    # index of the last model

a.make()
