from modeller import *    # Load standard Modeller classes
from modeller.automodel import *    # Load the automodel class

log.verbose()  #request verbose output
env = environ()  #create a new MODELLER environment to build this model
env.io.atom_files_directory = ['.'] #directories of input atom files

a = automodel(env,
              alnfile  = 'bak_T0955.pir',      # alignment filename
              knowns = ( 'meta_abi7_denovo2.pdb1',  'meta_abi6_denovo1.pdb1',  'meta_abi3_denovo7.pdb1',  'meta_abi6_denovo3.pdb1',  'meta_abi3_denovo0.pdb1',  'meta_abi6_denovo0.pdb1',  'meta_abi4_denovo7.pdb1',  'meta_abi2_denovo0.pdb1',  'meta_abi5_denovo4.pdb1',  'meta_abi4_denovo4.pdb1',  'meta_abi2_denovo6.pdb1',  'meta_abi4_denovo3.pdb1',  'meta_abi3_denovo4.pdb1',  'meta_abi3_denovo5.pdb1',  'meta_abi7_denovo6.pdb1',  'meta_abi3_denovo6.pdb1',  'meta_abi2_denovo5.pdb1',  'meta_abi2_denovo2.pdb1',  'meta_abi5_denovo5.pdb1',  'meta_abi7_denovo1.pdb1'), # codes of the templates
              sequence = 'T0955')   # code of the target
a.starting_model= 1             # index of the first model
a.ending_model  = 8    # index of the last model

a.make()
